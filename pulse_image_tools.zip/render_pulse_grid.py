
import json
import matplotlib.pyplot as plt
import numpy as np
import argparse

def render_pulse_image(json_path, cell_size=5, show=True, save_path=None):
    with open(json_path) as f:
        data = json.load(f)
    pulses = data["pulses"]
    max_row = max(p["row"] for p in pulses)
    max_col = max(p["col"] for p in pulses)

    img = np.ones((max_row * cell_size, max_col * cell_size, 3), dtype=np.uint8) * 255

    for p in pulses:
        r, c = p["row"] - 1, p["col"] - 1
        y1, y2 = r * cell_size, (r + 1) * cell_size
        x1, x2 = c * cell_size, (c + 1) * cell_size
        color_line = next((v for v in p["response"] if v.startswith("color:")), None)
        if color_line:
            color = color_line.split("color: ")[1].replace("rgb(", "").replace(")", "")
            rgb = tuple(int(x) for x in color.split(","))
            img[y1:y2, x1:x2] = rgb

    plt.imshow(img)
    plt.axis("off")
    if show:
        plt.show()
    if save_path:
        plt.imsave(save_path, img)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("json_path")
    parser.add_argument("--cell_size", type=int, default=5)
    parser.add_argument("--save_path", default=None)
    args = parser.parse_args()
    render_pulse_image(args.json_path, args.cell_size, save_path=args.save_path)
